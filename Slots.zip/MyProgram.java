import java.util.Scanner;
public class MyProgram
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        double balance = 0.0;
        Slot s1 = new Slot(4);
        Slot s2 = new Slot(8);
        Slot s3 = new Slot(16);
        s1.printTable();
        System.out.println(s1.spin() + " (" +  s1.getVal() + ")\n" + s2.spin() + " (" + s2.getVal() + ")\n" + s3.spin() + " (" + s3.getVal() + ")");
        //System.out.println(s1.getVal());
    }
}