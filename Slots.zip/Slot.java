public class Slot
{
    private int luck; // shhh it's totally random
    private double val;
    private String panel;
    private double[] table = new double[7];
    public Slot(int luck)
    {
        this.luck = luck;
        this.val = 0.0;
        this.panel = "";
        double a = 0.0; // it feels like this shouldn't work
        for (int i = 1; i <= 7; i++) // ...but, it does.
        {
            a += (Math.pow(0.5,i)) * 1000;
            table[i - 1] = a;
        }
    }
    
    public String spin()
    {
        val = (Math.random() * 1000);
        if (val <= table[0])
        {
            panel = "orange";
        }
        else if (val <= table[1])
        {
            panel = "banana";
        }
        else if (val <= table[2])
        {
            panel = "cherry";
        }
        else if (val <= table[3])
        {
            panel = "lemon";
        }
        else if (val <= table[4])
        {
            panel = "bell";
        }
        else if (val <= table[5])
        {
            panel = "horseshoe";
        }
        else if (val <= table[6])
        {
            panel = "diamond";
        }
        else 
        {
            panel = "seven";
        }
        return panel;
    }
    
    // public double spin(int l)
    // {
    //     /* I don't know if there's a curved random function so i'll make my own.
    //     The end result of this is a number between 0 and 1. Higher luck values
    //     make it more likely for the number to be close to 0. */
    //     for (int i = 0; i < l; i++) 
    //     {
    //         val += Math.random();
    //     }
    //     val = ((val / l) - 0.5) * 2;
    //     if (val < 0)
    //     {
    //         val = -val;
    //     }
    //     return val;
    // }
    
    // public double spin2(int l)
    // {
    //     /* an attempt at a different way of curving random numbers. 
    //     */ 
    //     val = 0.0;
    //     for (int i = 1; i <= l; i++)
    //     {
    //         val += (2*Math.pow((1.0/3.0),i)) * Math.random();
    //     }
    //     return val;
    // }
    
    // public double spin3(int l)
    // {
    //     val = 0.0;
    //     while (Math.random() > (l / 10.0))
    //     {
    //         val += Math.random();
    //     }
    //     return val;
    // }
    
    public void printTable()
    {
        for (int i = 0; i < 7; i++)
        {
            System.out.println(i + ": " + table[i]);
        }
    }
    
    public void setLuck(int l)
    {
        luck = l;
    }
    
    public double getVal()
    {
        return val;
    }
    
    public String getPanel()
    {
        return panel;
    }
}